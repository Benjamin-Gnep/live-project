<?php

	$user="RemoteUser";
	$host='123.57.41.237';
	$DBpassword='Remote1798164846';
	$dbName='Mask';
	
?>